<?php

define('QODE_RESTAURANT_VERSION', '2.0.1');
define('QODE_RESTAURANT_ABS_PATH', dirname(__FILE__));
define('QODE_RESTAURANT_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('QODE_RESTAURANT_CPT_PATH', QODE_RESTAURANT_ABS_PATH.'/post-types');
define('QODE_RESTAURANT_SHORTCODES_PATH', QODE_RESTAURANT_ABS_PATH.'/modules/shortcodes');