<?php

require_once 'register-template.php';
require_once 'dashboard-functions.php';