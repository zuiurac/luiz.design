<?php
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_highlights/highlights.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/_highlights/custom-styles/custom-styles.php';