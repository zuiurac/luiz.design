<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/numbered-process/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/numbered-process/numbered-process.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/numbered-process/numbered-process-item.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/numbered-process/options-map/map.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/numbered-process/custom-styles/custom-styles.php';