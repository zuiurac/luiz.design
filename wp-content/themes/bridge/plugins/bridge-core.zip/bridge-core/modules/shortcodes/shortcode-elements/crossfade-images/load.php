<?php
include_once BRIDGE_CORE_SHORTCODES_PATH.'/crossfade-images/functions.php';
include_once BRIDGE_CORE_SHORTCODES_PATH.'/crossfade-images/crossfade-images.php';