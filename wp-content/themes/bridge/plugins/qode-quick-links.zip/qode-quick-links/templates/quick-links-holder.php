<div class="qode-quick-links-holder">
	<?php qode_quick_links_button_html(); ?>
	<?php qode_quick_links_popup_html(); ?>
</div>