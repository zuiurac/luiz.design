<?php

include_once QODE_NEWS_SHORTCODES_PATH.'/post-carousel1/functions.php';
include_once QODE_NEWS_SHORTCODES_PATH.'/post-carousel1/post-carousel1.php';